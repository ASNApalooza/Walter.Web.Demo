﻿$(function () {   
    $("#stateList").change();
});